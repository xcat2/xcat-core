package com.cri.xcat.api.helpers;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.cri.xcat.api.IResponseHandler;
import com.cri.xcat.api.XcatConstants;
import com.cri.xcat.api.XcatInputStream;

/**
 * This class is the default handler for a xCAT response from the xCAT daemon.
 * It prints out the contents of the XML response to the console using SAX
 * parsing techniques.
 * <p>
 * This class manages error handling by logging and printing the error to the
 * console.
 * 
 * @author Scott Brown
 * 
 */
public class DefaultResponseHandler extends DefaultHandler implements IResponseHandler {
	
	/**
	 * Used for logging.
	 */
	private static final Log logger = LogFactory.getLog(DefaultResponseHandler.class);

	private String content;

	protected Map<String, List<String>> responseData;

	protected boolean serverDone;

	/**
	 * Logs the error that occurred and prints the error to the console.
	 */
	public void handleError(Exception e) {
		logger.warn("Handling your error: " + e.toString());
	}

	/**
	 * Saves the XML response to the an internal <bold>responseData</bold> Map.
	 * The map can be retrived using the <code>getResponseData</code> method.
	 * <p>
	 * Assumes each non-parent XML tag has text content which is assumed to be
	 * the value of the xml node.
	 * <p>
	 * Continues to read xCAT responses until the <code>serverdone</code> tag is
	 * met.
	 */
	public void handleXmlResponse(InputStream inputStream) {

		try {

			responseData = new HashMap<String, List<String>>();
			serverDone = false;

			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();

			while (!serverDone) {
				XcatInputStream xis = new XcatInputStream(inputStream);
				BufferedInputStream bis = new BufferedInputStream(xis);
				InputSource inputSource = new InputSource(bis);
				parser.parse(inputSource, this);
			}

		} catch (Exception e) {
			handleError(e);
		}

	}

	@Override
	public void endElement(String uri, String localName, String name) throws SAXException {

		if (name.equalsIgnoreCase(XcatConstants.SERVERDONE_XML_TAG)) {
			serverDone = true;
			logger.info("xCAT server notified client the server is done (via <serverdone> XML tag)");
		}

		if (content != null) {
			if (responseData.containsKey(name)) {
				// There already is a string of content value, add value to
				// existing list
				List<String> value = responseData.get(name);
				value.add(content);
			} else {
				List<String> value = new ArrayList<String>();
				value.add(content);
				responseData.put(name, value);
			}
		}
		content = null;
	}

	@Override
	public void characters(char buf[], int offset, int len) throws SAXException {
		String temp2;
		temp2 = new String(buf, offset, len).trim();
		if (!temp2.equals("")) {
			if (content == null) {
				content = temp2;
			} else {
				content = content.concat(temp2);
			}
		}
	}

	/**
	 * Returns a map that contains the information contained in the XML. The Map
	 * that is returned has a key equal to the tag name and a value equal to the
	 * XML tag and a value equal to the data inside the tag. If there was only 1
	 * XML tag of any name, the corresponding value in the map would be a List
	 * consisting of just 1 item (the text inside the XML tag).
	 * 
	 * @return a map that contains the information contained in the XML
	 */
	public Map<String, List<String>> getResponseData() {
		return responseData;
	}

}
