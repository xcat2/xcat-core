package com.cri.xcat.api;

import java.io.IOException;
import java.io.OutputStream;

import javax.net.ssl.SSLSocket;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.cri.xcat.api.helpers.DefaultResponseHandler;

/**
 * A request (also referred to as a command) is the basic information that is
 * sent to the xCAT daemon. This class is responsible for creating the
 * appropriate XML to send to xcatd as well as submitting this request to the
 * server. The communication to the server is done via a xCAT connection object.
 * 
 * @author Scott Brown
 * 
 */
public abstract class Request {

	/**
	 * Used for logging.
	 */
	private static final Log logger = LogFactory.getLog(Request.class);

	private Connection connection;

	private IResponseHandler handler;

	/**
	 * The timeout used to read data from the socket to xCAT (in milliseconds).
	 * NOTE: this is not used if the implementer overrides the
	 * <code>submitRequest</code> method.
	 */
	private int socketTimeOut = XcatConstants.DEFAULT_SOCKET_TIMEOUT;

	/**
	 * Creates the XML and sends it to the xCAT server. The XML root tag should
	 * be <bold>xcatrequest</bold>.
	 * 
	 * @param stream
	 *            The OutputStream from the SSL socket to the xCAT server. The
	 *            XML created should be sent to this output stream.
	 * @throws XcatCommunicationException
	 */
	public abstract void buildXmlOutputStream(OutputStream stream)
			throws XcatCommunicationException;

	/**
	 * Gets the connection used to create the socket.
	 * 
	 * @return the connection used to create the socket
	 */
	public Connection getConnection() {
		return connection;
	}

	/**
	 * Gets the handler used to handle XML responses and any errors that might
	 * have occurred.
	 * 
	 * @return the handler used to handle XML responses and any errors that
	 *         might have occurred
	 */
	public IResponseHandler getHandler() {
		return handler;
	}

	/**
	 * Gets the timeout used to read data from the socket to xCAT (in
	 * milliseconds). NOTE: this is not used if the implementer overrides the
	 * <code>submitRequest</code> method.
	 * <p>
	 * A value of 0 represents an infinite timeout (or no timeout).
	 * <p>
	 * Default value set to <bold>8000</bold>.
	 * 
	 * @return The timeout used to read data from the socket to xCAT (in
	 *         milliseconds).
	 */
	public int getSocketTimeOut() {
		return socketTimeOut;
	}

	/**
	 * Sets the timeout used to read data from the socket to xCAT (in
	 * milliseconds). NOTE: this is not used if the implementer overrides the
	 * <code>submitRequest</code> method.
	 * <p>
	 * Setting the value to 0 represents an infinite timeout (or no timeout)
	 * <p>
	 * Default value set to <bold>8000</bold>.
	 * 
	 * @param socketTimeOut
	 *            The timeout used to read data from the socket to xCAT (in
	 *            milliseconds).
	 */
	public void setSocketTimeOut(int socketTimeOut) {
		this.socketTimeOut = socketTimeOut;
	}

	/**
	 * Submits a request to the xCAT daemon using the connection passed in and a
	 * new <code>DefaultResponseHandler</code> as the handler.
	 * 
	 * @param connection
	 *            the connection used to create a socket connection to xcatd
	 */
	public void submitRequest(Connection connection) {
		submitRequest(connection, new DefaultResponseHandler());
	}

	/**
	 * Submits a request to the xCAT daemon using the connection and handler
	 * passed in.
	 * 
	 * @param connection
	 *            the connection used to create a socket connection to xcatd
	 * @param handler
	 *            the handler used to handle the XML response or any errors that
	 *            occurred.
	 */
	public void submitRequest(Connection connection, IResponseHandler handler) {
		this.connection = connection;
		this.handler = handler;
		
		try {
			SSLSocket s = connection.createSocket();

			s.setSoTimeout(socketTimeOut);
			logger.debug("Socket timeout set to " + socketTimeOut);

			// Send encrypted OutputStream to XMLGenerator
			OutputStream out = s.getOutputStream();
			buildXmlOutputStream(out);
			out.flush();

			logger.info("Connection established to xcatd");

			// Let the handler handle the response.
			handler.handleXmlResponse(s.getInputStream());

			// Close the output stream and the socket
			out.close();
			s.close();

		} catch (IOException e) {
			handler.handleError(e);
		} catch (XcatCommunicationException e) {
			handler.handleError(e);
		}
	}

}
