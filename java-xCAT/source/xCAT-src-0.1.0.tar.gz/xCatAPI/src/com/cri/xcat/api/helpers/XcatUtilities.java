package com.cri.xcat.api.helpers;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.cri.xcat.api.XcatConstants;

/**
 * Contains various helper functions that are useful in dealing with xCAT
 * communications.
 * 
 * @author Scott Brown
 * 
 */
public class XcatUtilities {

	/**
	 * Creates an XML document in the format that xcatd would expect from the
	 * input map. The key for each value is set to the XML tag name while the
	 * value is set to the text content inside the XML tag. If the value of the
	 * object is <code>Iterable</code> (a collection of some kind), then each
	 * value inside the collection gets a separate tag with the text content
	 * inside set to the String value of the item.
	 * 
	 * @param map
	 *            The map that will be used to create the XML
	 * @return an XML document that xcatd would expect
	 * 
	 * @throws ParserConfigurationException
	 */
	public static Document createXmlDocument(Map<String, Object> map)
			throws ParserConfigurationException {

		// get an instance of factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		// get an instance of builder
		DocumentBuilder db = dbf.newDocumentBuilder();

		// create an instance of DOM
		Document dom = db.newDocument();

		// root element is 'xcatrequest'
		Element rootEle = dom.createElement(XcatConstants.REQUEST_ROOT_XML_TAG);
		dom.appendChild(rootEle);

		// child elements determined from input map
		for (String key : map.keySet()) {

			Object obj = map.get(key);

			if (obj instanceof Iterable) {
				Iterator itr = ((Iterable) obj).iterator();
				while (itr.hasNext()) {
					Element childEle = dom.createElement(key);
					childEle.setTextContent(String.valueOf(itr.next()));
					rootEle.appendChild(childEle);
				}
			} else {
				Element childEle = dom.createElement(key);
				childEle.setTextContent(String.valueOf(obj));
				rootEle.appendChild(childEle);
			}

		}

		return dom;
	}

	/**
	 * Takes an XML document and sends it to the output stream in a way that
	 * xcatd would expect. Specifically, xcatd requires the XML declaration to
	 * be omitted from the request.
	 * 
	 * @param dom
	 *            the XML document that will be sent to the output stream.
	 * @param stream
	 *            the output stream from the socket that would be the connection
	 *            to xcatd
	 * @throws TransformerException
	 */
	public static void xmlToOutputStream(Document dom, OutputStream stream)
			throws TransformerException {

		DOMSource domSource = new DOMSource(dom);
		StreamResult streamResult = new StreamResult(stream);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer serializer = tf.newTransformer();
		serializer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
		serializer.setOutputProperty(OutputKeys.INDENT, "yes");
		serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		serializer.transform(domSource, streamResult);

	}

	/**
	 * Returns true if the string is null or an empty string.
	 * 
	 * @param str
	 *            the string to check.
	 * @return true if the string is null or an empty string; false, otherwise.
	 */
	public static boolean isEmpty(String str) {
		return (str == null || str.equals(""));
	}

}
