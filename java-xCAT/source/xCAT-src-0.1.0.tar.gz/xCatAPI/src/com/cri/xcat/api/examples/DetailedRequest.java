package com.cri.xcat.api.examples;

import java.io.OutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.cri.xcat.api.XcatCommunicationException;
import com.cri.xcat.api.helpers.BasicRequest;
import com.cri.xcat.api.helpers.XcatUtilities;

public class DetailedRequest extends BasicRequest {
	
	public DetailedRequest(String commandName) {
		super(commandName);
	}

	private String transactionId;

	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	
	@Override
	public void buildXmlOutputStream(OutputStream stream) throws XcatCommunicationException {

		// get an instance of factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {
			// get an instance of builder
			DocumentBuilder db = dbf.newDocumentBuilder();

			// create an instance of DOM
			Document dom = db.newDocument();

			// root element is 'xcatrequest'
			Element rootEle = dom.createElement("xcatrequest");
			dom.appendChild(rootEle);
			
			for (String arg : getArgs()) {
				Element argEle = dom.createElement("arg");
				argEle.setTextContent(arg);
				rootEle.appendChild(argEle);
			}

			Element cmdEle = dom.createElement("command");
			cmdEle.setTextContent(getCommandName());
			rootEle.appendChild(cmdEle);
			
			Element cwdEle = dom.createElement("cwd");
			cwdEle.setTextContent(System.getProperty("user.dir"));
			rootEle.appendChild(cwdEle);
			
			XcatUtilities.xmlToOutputStream(dom, stream);
			
		} catch (TransformerException e) {
			throw new XcatCommunicationException("Could not send XML to output stream", e);
		} catch (ParserConfigurationException e) {
			throw new XcatCommunicationException("Could not build the XML for the request", e);
		}
	}

}
