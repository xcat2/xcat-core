package com.cri.xcat.api;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;

import javax.net.ssl.SSLSocket;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.ssl.SSLClient;
import org.apache.commons.ssl.TrustMaterial;

/**
 * This class contains the information needed to make a valid SSL socket
 * connection to an xCAT daemon. By default, the hostname of the xCAT daemon is
 * set to <bold>localhost</bold> and the port is set to <bold>3001</bold>. Since
 * the connection to xCAT requires security information to make the SSL
 * connection, users can add certificate files to make a secure connection.
 * 
 * @author Scott Brown
 * 
 */
public class Connection {

	/**
	 * Used for logging.
	 */
	private static final Log logger = LogFactory.getLog(Connection.class);

	private String hostname;

	private int port;

	private SSLClient client;

	/**
	 * Create a new connection to an xCAT daemon using hostname of "localhost"
	 * port of "3001", and the default xCAT certificate files: "ca.pem" &
	 * "client-cred.pem" located in the default xCAT directory.
	 * 
	 * @throws IOException
	 *             If there was an error creating a SSLClient
	 * @throws GeneralSecurityException
	 *             If there was an error creating a SSLClient
	 * 
	 * @see org.apache.commons.ssl.SSLClient
	 * 
	 */
	public Connection() throws GeneralSecurityException, IOException {
		this(XcatConstants.DEFAULT_HOSTNAME, XcatConstants.DEFAULT_PORT);
	}

	/**
	 * Create a new connection to an xCAT daemon with the hostname and port
	 * specified.
	 * <p>
	 * This connection will also attempt to locate the <bold>ca.pem</bold> and
	 * <bold>client-cred.pem</bold> certificate files from the default xCAT
	 * directory. If these files are not present, an exception will be thrown.
	 * 
	 * @param hostname
	 *            The host name of the xcatd instance.
	 * 
	 * @param port
	 *            The port that xcatd is listening on.
	 * 
	 * @throws IOException
	 *             If there was an error creating a SSLClient or the default
	 *             certificate files were not found.
	 * @throws GeneralSecurityException
	 *             If there was an error creating a SSLClient
	 * 
	 * @see org.apache.commons.ssl.SSLClient
	 */
	public Connection(String hostname, int port) throws GeneralSecurityException, IOException {

		this(hostname, port, null);

		// Attempt to find the xcat certificates in user home directory
		String homeDir = System.getProperty("user.home");
		addCertificateFile(new File(homeDir.concat("/.xcat/ca.pem")));
		addCertificateFile(new File(homeDir.concat("/.xcat/client-cred.pem")));

	}

	/**
	 * Create a new connection to an xCAT daemon with the hostname and port
	 * specified, and adds the security information from the security files
	 * specified.
	 * 
	 * @param hostname
	 *            The host name of the xcatd instance.
	 * 
	 * @param port
	 *            The port that xcatd is listening on.
	 * 
	 * @param certificateFiles
	 *            An array of files that contain the certificate security
	 *            information needed to connect to the xCAT server.
	 * 
	 * @throws IOException
	 *             If there was an error creating a SSLClient or the default
	 *             certificate files were not found.
	 * @throws GeneralSecurityException
	 *             If there was an error creating a SSLClient
	 * 
	 * @see org.apache.commons.ssl.SSLClient
	 */
	public Connection(String hostname, int port, File[] certificateFiles)
			throws GeneralSecurityException, IOException {
		this.hostname = hostname;
		this.port = port;

		// create basic ssl client
		client = new SSLClient();

		// Trust the defaults plus any xcat certificates
		client.addTrustMaterial(TrustMaterial.DEFAULT);

		if (certificateFiles != null) {
			for (File file : certificateFiles) {
				client.addTrustMaterial(new TrustMaterial(file));
			}
		}
	}

	/**
	 * Adds the certificate file security information to the SSL client. The
	 * xCAT server requires authentication to create an SSL connection. During
	 * the xCAT install, PEM certificate files containing security information
	 * are created to allow clients to connect to the xCAT server. By default
	 * these files were named <bold>client-cred.pem</bold> and
	 * <bold>ca.pem</bold> and were placed in the <bold>.xcat</bold> directory.
	 * <p>
	 * This method allows the user to specify the certificate files that are
	 * required to connect to the xCAT server.
	 * 
	 * @param certFile
	 *            The certificate file used to create a SSL connection to
	 *            the xCAT server.
	 * @throws IOException
	 *             Exception thrown if there was a problem with IO when
	 *             accessing the file.
	 * @throws GeneralSecurityException
	 * 
	 * @see org.apache.commons.ssl.SSLClient
	 */
	public void addCertificateFile(File certFile) throws IOException, GeneralSecurityException {
		TrustMaterial tm = new TrustMaterial(certFile);
		client.addTrustMaterial(tm);
		logger.info("Added PEM File " + certFile.getAbsolutePath() + " to SSL client");
	}

	/**
	 * Gets the host name of the server running the xCAT daemon.
	 * 
	 * @return the host name of the server running the xCAT daemon
	 */
	public String getHostname() {
		return hostname;
	}

	/**
	 * Gets the port number of which the xCAT daemon is listening for incoming
	 * requests.
	 * 
	 * @return the port number of which the xCAT daemon is listening for
	 *         incoming requests.
	 */
	public int getPort() {
		return port;
	}

	/**
	 * Sets the host name of the server running the xCAT daemon.
	 * 
	 * @param hostname
	 *            the host name of the server running the xCAT daemon
	 */
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	/**
	 * Sets the port number of which the xCAT daemon is listening for incoming
	 * requests.
	 * <p>
	 * Port range must be from 1 to 65535.
	 * 
	 * @param port
	 *            the port number of which the xCAT daemon is listening for
	 *            incoming requests
	 */
	public void setPort(int port) {
		if (port < 1 || port > 65535) {
			throw new IllegalArgumentException(
					"Port number invalid! Range is from 1 to 65535 (Attempting to set to " + port
							+ ")");
		}
		this.port = port;
	}

	/**
	 * Creates a SSL socket from the SSLClient.
	 * 
	 * @return a SSL socket to the host using the set port.
	 * 
	 * @throws IOException
	 * 
	 * @see org.apache.commons.ssl.SSLClient
	 */
	public SSLSocket createSocket() throws IOException {
		SSLSocket s = (SSLSocket) client.createSocket(getHostname(), getPort());
		logger.info("Creating SSL socket to host");
		return s;
	}
}
