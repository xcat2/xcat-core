package com.cri.xcat.api;

public class XcatCommunicationException extends Exception {

	/**
	 * Constructor for a XcatCommunicationException
	 * 
	 * @param message
	 *            Some descriptive message
	 * @param cause
	 *            The Exception detected indicating a problem contacting xCAT
	 *            (eg. SAXParseException)
	 */
	public XcatCommunicationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructor for a XcatCommunicationException
	 * 
	 * @param message
	 *            Some descriptive message
	 */
	public XcatCommunicationException(String message) {
		super(message);
	}

}
