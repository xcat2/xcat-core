package com.cri.xcat.api.examples;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.cri.xcat.api.Connection;
import com.cri.xcat.api.helpers.BasicRequest;
import com.cri.xcat.api.helpers.DefaultResponseHandler;

/**
 * This class sends a basic request to xcatd (tabdump site) and gets the
 * response.
 * 
 * @author Scott Brown
 * 
 */
public class BasicTest {

	public static void main(String[] args) {
		try {
			
			// My certificate files are NOT in the default location
			File[] fileArray = new File[2];
			fileArray[0] = new File("/home/scott/.xcat/i1/client-cred.pem");
			fileArray[1] = new File("/home/scott/.xcat/i1/ca.pem");
			
			// Create connection to server called 'i1'
			Connection connect = new Connection("i1", 3001, fileArray);

			// Create command
			BasicRequest request = new BasicRequest("tabdump");

			String[] cmdArgs = new String[1];
			cmdArgs[0] = "site";
			request.setArgs(cmdArgs);

			DefaultResponseHandler handler = new DefaultResponseHandler();
			request.submitRequest(connect, handler);
			Map<String, List<String>> responseData = handler.getResponseData();

			// Response received, printing data
			for (String key : responseData.keySet()) {
				List<String> value = responseData.get(key);
				for (String name : value) {
					System.out.println(key + ": " + name);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
