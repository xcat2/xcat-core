package com.cri.xcat.api.examples;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.cri.xcat.api.Connection;
import com.cri.xcat.api.IResponseHandler;

public class SpecificTest {

	public static void main(String[] args) {
		
		SpecificResponseHandler myHandler = new SpecificResponseHandler();
		
		try {
			Connection connect = new Connection("hostname", 3001);
			DetailedRequest request = new DetailedRequest("cmdName");

			String[] cmdArgs = new String[3];
			cmdArgs[0] = "arg1";
			cmdArgs[1] = "arg2";
			cmdArgs[2] = "arg3";
			request.setArgs(cmdArgs);

			request.setTransactionId("501");

			request.submitRequest(connect, new SpecificResponseHandler());
		} catch (Exception e) {
			myHandler.handleError(e);
		}
	}

}

class SpecificResponseHandler implements IResponseHandler {

	public SpecificResponseHandler() {

	}

	public void handleError(Exception e) {
		//e.printStackTrace();
		System.out.println("Special handling of error " + e.toString());
	}

	public void handleXmlResponse(InputStream inputStream) {
		// Now read in data
		BufferedReader bf = new BufferedReader(new InputStreamReader(
				inputStream));
		
		String outStr;
		System.out.println("Output from server: ");
		try {
			while ((outStr = bf.readLine()).contains("</xcatresponse>") == false) {
				System.out.print(outStr);
			}
			System.out.println(outStr);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
