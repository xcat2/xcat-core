package com.cri.xcat.api;

import java.io.InputStream;

/**
 * This interface is used for handling an xCAT response (from the xCAT daemon).
 * The methods included in this interface allow a class that would like to
 * handle an xCAT response the necessarily functionality needed to handle either
 * the XML response or the error that occurred while attempting the
 * communication.
 * 
 * @author Scott Brown
 * 
 */
public interface IResponseHandler {

	/**
	 * This method is called when an error has occurred while attempting to
	 * submit a request (send a command) to the xCAT daemon. It can be called at
	 * any time during the communication process, even while the client is
	 * handling the XML response from the server.
	 * 
	 * @param e
	 *            The error that occurred.
	 */
	public void handleError(Exception e);

	/**
	 * This method takes the InputStream from the SSL socket connection and
	 * parses it. The InputStream is the response from xcatd after a request is
	 * made to the daemon.
	 * <p>
	 * The response is in a XML format with the root XML tag of
	 * <bold>xcatresponse</bold>. According to the xCAT documentation, a valid
	 * XML response can be in various formats. There are 3 specifically
	 * mentioned in the documentation that are listed below:
	 * <p>
	 * 
	 * <pre>
	 * 1.	&lt;xcatresponse&gt;
	 *       &lt;data&gt;...&lt;/data&gt;
	 *       &lt;data&gt;...&lt;/data&gt;
	 *                   ...
	 *       &lt;data&gt;...&lt;/data&gt;
	 *      &lt;/xcatresponse&gt;
	 * </pre>
	 * 
	 * <p>
	 * In this format, there can be multiple <bold>data</bold> tags.
	 * <p>
	 * 
	 *<pre>
	 * 2.	&lt;xcatresponse&gt;
	 *   	 &lt;data&gt;
	 *        &lt;desc&gt;desc1&lt;/desc&gt;
	 *        &lt;contents&gt;contents1&lt;/contents&gt;
	 *       &lt;/data&gt;
	 *       &lt;data&gt;
	 *        &lt;desc&gt;desc2&lt;/desc&gt;
	 *        &lt;contents&gt;contents2&lt;/contents&gt;
	 *       &lt;/data&gt;
	 *      &lt;/xcatresponse&gt;
	 * </pre>
	 * 
	 * <p>
	 * NOTE: In this format, only the data array can have more than one element.
	 * All other arrays are assumed to be a single element.
	 * <p>
	 * 
	 * <pre>
	 * 3.	&lt;xcatresponse&gt;
	 *       &lt;node&gt;
	 *        &lt;name&gt;node1&lt;/name&gt;
	 *   	  &lt;data&gt;
	 *         &lt;desc&gt;node 1 desc&lt;/desc&gt;
	 *         &lt;contents&gt;node 1 contents&lt;/contents&gt;
	 *        &lt;/data&gt;
	 *       &lt;/node&gt;
	 *       &lt;node&gt;
	 *        &lt;name&gt;node2&lt;/name&gt;
	 *   	  &lt;data&gt;
	 *         &lt;desc&gt;node 2 desc&lt;/desc&gt;
	 *         &lt;contents&gt;node 2 contents&lt;/contents&gt;
	 *        &lt;/data&gt;
	 *       &lt;/node&gt;
	 *      &lt;/xcatresponse&gt;
	 * </pre>
	 * 
	 * <p>
	 * NOTE: Only the node array can have more than one element. All other
	 * arrays are assumed to be a single element.
	 * 
	 * <p>
	 * The response from xcatd may also contain an error. The error will be
	 * specified in the XML response and in which case the client should
	 * recognize this error and respond accordingly. NOTE: The
	 * <code>handleError</code> method is not automatically called when xcatd
	 * responds with valid XML containing an error message. This is up to the
	 * client.
	 * 
	 * @param inputStream
	 *            the input stream from the xCAT daemon to this client.
	 */
	public void handleXmlResponse(InputStream inputStream);

}
