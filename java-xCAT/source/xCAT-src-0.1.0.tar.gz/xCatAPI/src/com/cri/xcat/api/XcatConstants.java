package com.cri.xcat.api;

public class XcatConstants {
	
	/**
	 * The default root tag for the XML request that is sent to the xCAT server.
	 */
	public static final String REQUEST_ROOT_XML_TAG = "xcatrequest";
	
	/**
	 * This is the root XML tag for all of xcatd's responses.
	 */
	public static final String RESPONSE_ROOT_XML_TAG = "xcatresponse";

	/**
	 * This is the XML tag that signifies the server is done processing the
	 * request.
	 */
	public static final String SERVERDONE_XML_TAG = "serverdone";
	
	/**
	 * The default host which is running the xCAT daemon. Set to
	 * <bold>localhost</bold>.
	 */
	public static final String DEFAULT_HOSTNAME = "localhost";

	/**
	 * The default port which the xCAT daemon is listening on. Set to
	 * <bold>3001</bold>.
	 */
	public static final int DEFAULT_PORT = 3001;

	/**
	 * The default socket timeout (in milliseconds) to listen for a response
	 * from the xCAT server. Set to <bold>8000</bold>
	 */
	public static final int DEFAULT_SOCKET_TIMEOUT = 8000;

}
