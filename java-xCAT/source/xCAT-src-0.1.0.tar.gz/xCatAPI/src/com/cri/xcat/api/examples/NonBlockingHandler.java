package com.cri.xcat.api.examples;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.Observer;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.cri.xcat.api.IResponseHandler;
import com.cri.xcat.api.XcatConstants;
import com.cri.xcat.api.XcatInputStream;

public class NonBlockingHandler extends DefaultHandler implements IResponseHandler {

	private Observer observer;

	private boolean serverDone;
	
	private String content;
	
	public NonBlockingHandler(Observer observer){
		this.observer = observer;
	}
	
	public void handleXmlResponse(InputStream inputStream) {

		try {
			serverDone = false;

			SAXParserFactory factory = SAXParserFactory.newInstance();
			final SAXParser parser = factory.newSAXParser();

			while (!serverDone) {
				XcatInputStream xis = new XcatInputStream(inputStream);
				BufferedInputStream bis = new BufferedInputStream(xis);
				final InputSource inputSource = new InputSource(bis);

				new Thread("Handle xCAT XML Response Thread") {
					public void run() {
						try {
							parser.parse(inputSource, NonBlockingHandler.this);
						} catch (Exception e) {
							handleError(e);
						}
					}
				}.start();

			}

		} catch (Exception e) {
			handleError(e);
		}

	}
	
	@Override
	public void characters(char buf[], int offset, int len) throws SAXException {
		String temp2;
		temp2 = new String(buf, offset, len).trim();
		if (!temp2.equals("")) {
			if (content == null) {
				content = temp2;
			} else {
				content = content.concat(temp2);
			}
		}
	}

	@Override
	public void endDocument() throws SAXException {
		super.endDocument();
		if (serverDone) {
			observer.update(null, "Request Finished");
		}
	}
	
	@Override
	public void endElement(String uri, String localName, String name) throws SAXException {
		if (name.equalsIgnoreCase(XcatConstants.SERVERDONE_XML_TAG)) {
			serverDone = true;
		} else if (content != null) {
			observer.update(null, name + ":" + content);
		}
		content = null;
	}

	public void handleError(Exception e) {
		// TODO Auto-generated method stub
	}

}
