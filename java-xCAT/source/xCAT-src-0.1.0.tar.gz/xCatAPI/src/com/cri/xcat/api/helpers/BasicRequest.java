package com.cri.xcat.api.helpers;

import java.io.OutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.cri.xcat.api.Request;
import com.cri.xcat.api.XcatCommunicationException;

/**
 * BasicRequest extends the base Request class and represents a basic xCAT
 * request to the xCAT daemon. A request is also commonly referred to as a
 * command. A basic xCAT request (or command) consists of four parts:
 * <ul>
 * <li>The name of the command
 * <li>A list of arguments for the command
 * <li>The current working directory
 * <li>The node range
 * </ul>
 * <p>
 * Not all requests must use all four parts. For a BasicRequest, only the
 * commandName must be explicitly set by the user. For the node range and
 * argument list, only if values are set will the resulting XML contain these
 * fields, otherwise no node range or argument list is sent to the xCAT daemon.
 * <p>
 * The current working directory is also always sent to the xCAT daemon, but
 * this information can be found by using the System's user directory if the
 * user does not explicitly set this value. The user cannot however set the
 * current working directory to <code>null</code> as the xCAT daemon is
 * expecting this information.
 * <p>
 * For example, if a user creates a BasicRequest but only sets the node range
 * value to "n01", the following information will be sent to the xCAT daemon:
 * <ul>
 * <li>The name of the command
 * <li>The current working directory (found using the System's user directory)
 * <li>A node range of "n01"
 * </ul>
 * 
 * @author Scott Brown
 * 
 */
public class BasicRequest extends Request {

	/**
	 * The argument list. Can be<code>null</code> or empty.
	 */
	private String[] args;

	/**
	 * Name of the command to send to xCAT. CANNOT be <code>null</code> or
	 * empty.
	 */
	private String commandName;

	/**
	 * The current working directory.
	 */
	private String currentWorkingDirectory;

	/**
	 * This is the node range. Can be <code>null</code>.
	 */
	private String nodeRange;

	/**
	 * Default Constructor that creates a Basic Request with the command name
	 * equal to the input parameter.
	 * 
	 * @param commandName
	 *            the name of the command which will be sent to the xCAT daemon.
	 */
	public BasicRequest(String commandName) {
		if (XcatUtilities.isEmpty(commandName))
			throw new IllegalArgumentException("commandName cannot be empty!");

		this.commandName = commandName;
	}

	@Override
	public void buildXmlOutputStream(OutputStream stream) throws XcatCommunicationException {

		// get an instance of factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {
			// get an instance of builder
			DocumentBuilder db = dbf.newDocumentBuilder();

			// create an instance of DOM
			Document dom = db.newDocument();

			// root element is 'xcatrequest'
			Element rootEle = dom.createElement("xcatrequest");
			dom.appendChild(rootEle);

			if (getArgs() != null) {
				for (String arg : getArgs()) {
					Element argEle = dom.createElement("arg");
					argEle.setTextContent(arg);
					rootEle.appendChild(argEle);
				}
			}

			Element cmdEle = dom.createElement("command");
			cmdEle.setTextContent(getCommandName());
			rootEle.appendChild(cmdEle);

			Element cwdEle = dom.createElement("cwd");
			if (XcatUtilities.isEmpty(currentWorkingDirectory)) {
				currentWorkingDirectory = System.getProperty("user.dir");
			}
			cwdEle.setTextContent(currentWorkingDirectory);
			rootEle.appendChild(cwdEle);

			if (!XcatUtilities.isEmpty(getNodeRange())) {
				Element nrEle = dom.createElement("noderange");
				nrEle.setTextContent(getNodeRange());
				rootEle.appendChild(nrEle);
			}

			XcatUtilities.xmlToOutputStream(dom, stream);

		} catch (TransformerException e) {
			throw new XcatCommunicationException("Could not send XML to output stream", e);
		} catch (ParserConfigurationException e) {
			throw new XcatCommunicationException("Could not build the XML for the request", e);
		}
	}

	/**
	 * Gets the list of arguments that will be sent to the xCAT deamon with the
	 * command.
	 * <p>
	 * May return <code>null</code> if the argument list was never set or was
	 * set to <code>null</code>.
	 * 
	 * @return a list of arguments that will be sent to the xCAT deamon with the
	 *         command
	 */
	public String[] getArgs() {
		return args;
	}

	/**
	 * Gets the name of the command that will be sent to the xCAT deamon.
	 * 
	 * @return the name of the command that will be sent to the xCAT deamon
	 */
	public String getCommandName() {
		return commandName;
	}

	/**
	 * Gets the current working directory.
	 * <p>
	 * May return <code>null</code> if the directory was never set or was set to
	 * <code>null</code>.
	 * 
	 * @return the user-specified current working directory
	 */
	public String getCurrentWorkingDirectory() {
		return currentWorkingDirectory;
	}

	/**
	 * Get the node range for the command.
	 * <p>
	 * May return <code>null</code> if the range was never set or was set to
	 * <code>null</code>.
	 * 
	 * @return the node range
	 */
	public String getNodeRange() {
		return nodeRange;
	}

	/**
	 * Sets the list of arguments that will be sent to the xCAT deamon with the
	 * command.
	 * 
	 * @param args
	 *            the list of arguments that will be sent to the xCAT deamon
	 *            with the command
	 */
	public void setArgs(String[] args) {
		this.args = args;
	}

	/**
	 * Sets the name of the command that will be sent to the xCAT deamon. The
	 * commandName is the only part of a BasicRequest which must be explicitly
	 * specified by the user.
	 * <p>
	 * Cannot be empty or <code>null</code>.
	 * 
	 * @param name
	 *            the name of the command that will be sent to the xCAT deamon
	 */
	public void setCommandName(String name) {
		if (XcatUtilities.isEmpty(name))
			throw new IllegalArgumentException("commandName cannot be empty or null!");

		this.commandName = name;
	}

	/**
	 * Set the current working directory for the xCAT request. The xCAT deamon
	 * requires a current directory for most commands, and if this value is
	 * never set (or set to <code>null</code>), the System's user directory is
	 * used.
	 * 
	 * @param currentWorkingDirectory
	 *            the current working directory for the xCAT request
	 */
	public void setCurrentWorkingDirectory(String currentWorkingDirectory) {
		this.currentWorkingDirectory = currentWorkingDirectory;
	}

	/**
	 * Set the node range for the request.
	 * 
	 * @param nodeRange
	 *            node range for the request
	 */
	public void setNodeRange(String nodeRange) {
		this.nodeRange = nodeRange;
	}

}
