package com.cri.xcat.api;

import java.io.IOException;
import java.io.InputStream;

/**
 * Extends any InputStream by forcing a input stream to report the end of
 * reading once a <bold>
 * 
 * <pre>
 * &lt;/xcatresponse&gt;
 * </pre>
 * 
 * </bold> tag is read in. After this point, all other <code>read</code> calls
 * will return a <code>-1</code> (signifying the end of the stream).
 * <p>
 * This class is useful when attempting to use a SAX parser on the XML response
 * from the xCAT daemon. By default, a SAX handler will attempt to read even
 * after the entire XML response is read in (because the handler has no idea the
 * entire message has been received). This would result in the socket attempting
 * to read after there is no more data left, causing a timeout on the socket and
 * an error being thrown. This class fixes this problem by searching for the end
 * response tag and forcing a end of stream after that tag.
 * <p>
 * This class, as well as the other types of InputStream classes uses the
 * decorator design pattern to add specific functionality to an input stream.
 * 
 * @author Scott Brown
 * 
 */
public class XcatInputStream extends InputStream {

	private StringBuffer strBuff;

	private boolean hitEndResponseTag = false;

	private InputStream stream;

	private String endResponseTag = new String("</"
			+ XcatConstants.RESPONSE_ROOT_XML_TAG + ">");

	/**
	 * The constructor for this class must include an input stream to decorate.
	 * 
	 * @param stream
	 *            The input stream that will be decorated.
	 */
	public XcatInputStream(InputStream stream) {
		this.stream = stream;
		strBuff = new StringBuffer(15);
	}

	@Override
	public int read() throws IOException {

		// If the end response tag has been met, return -1 signifying the end of
		// the stream.
		if (hitEndResponseTag)
			return -1;

		char c = (char) stream.read();
		strBuff.append(c);
		if (endResponseTag.startsWith(strBuff.toString())) {
			hitEndResponseTag = (endResponseTag.equalsIgnoreCase(strBuff
					.toString()));
		} else {
			strBuff.delete(0, 15);
		}

		return c;
	}

}
