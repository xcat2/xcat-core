package com.cri.xcat.api.examples;

import java.util.Observable;
import java.util.Observer;

import com.cri.xcat.api.Connection;
import com.cri.xcat.api.helpers.BasicRequest;

/**
 * This request is a time consuming request, and therefore we do not want to
 * wait for it to complete, but instead just be notified when new messages
 * appear.
 * 
 * @author Scott Brown
 * 
 */
public class CreateRequest {

	public static void main(String[] args) {
		LongRequestSubmitter submitter = new LongRequestSubmitter();
		submitter.submitNonBlockingRequest();
	}

}

class LongRequestSubmitter implements Observer {

	public void submitNonBlockingRequest() {
		try {
			Connection connect = new Connection("i1", 3001);

			// Create command (mknb is a command that takes a while)
			BasicRequest request = new BasicRequest("mknb");
			
			//Set the timeout for a longer amount to avoid a timeout error
			request.setSocketTimeOut(20000);

			String[] cmdArgs = new String[1];
			cmdArgs[0] = "x86_64";
			request.setArgs(cmdArgs);

			NonBlockingHandler handler = new NonBlockingHandler(this);

			request.submitRequest(connect, handler);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void update(Observable o, Object arg) {
		System.out.println(String.valueOf(arg));
	}

}
