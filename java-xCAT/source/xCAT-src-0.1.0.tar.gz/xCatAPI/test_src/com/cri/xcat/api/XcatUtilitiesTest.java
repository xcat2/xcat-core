package com.cri.xcat.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import junit.framework.TestCase;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import com.cri.xcat.api.helpers.XcatUtilities;

public class XcatUtilitiesTest extends TestCase {

	public void testStringsMap() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("command", "commandName");
		map.put("noderange", "n5-6");
		map.put("arg", "argument");
		try {
			Document doc = XcatUtilities.createXmlDocument(map);
			Node root = doc.getFirstChild();
			assertTrue("Could not find root element", (root != null));
			assertTrue("Root element must be xcatrequest", root.getNodeName()
					.compareToIgnoreCase("xcatrequest") == 0);

			NodeList nodes = root.getChildNodes();
			assertTrue("number of child nodes for this request should be 3",
					(nodes.getLength() == 3));

			for (int i = 0; i < nodes.getLength(); i++) {
				Node node = nodes.item(i);
				if (node.getNodeName().equals("command")) {
					assertEquals("Command should be commandName", node
							.getTextContent(), "commandName");
				} else if (node.getNodeName().equals("noderange")) {
					assertEquals("noderange should be n5-6", node
							.getTextContent(), "n5-6");
				} else if (node.getNodeName().equals("arg")) {
					assertEquals("arg should be argument", node
							.getTextContent(), "argument");
				}
			}

		} catch (ParserConfigurationException e) {
			fail("should not fail");
		}
	}

	public void testListAndStringMap() {
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("command", "commandName");
		map.put("noderange", "n5-6");

		List<String> args = new ArrayList<String>();
		args.add("arg1");
		args.add("arg2");
		args.add("arg3");

		map.put("arg", args);

		try {
			Document doc = XcatUtilities.createXmlDocument(map);
			Node root = doc.getFirstChild();
			assertTrue("Could not find root element", (root != null));
			assertTrue("Root element must be xcatrequest", root.getNodeName()
					.compareToIgnoreCase("xcatrequest") == 0);

			NodeList nodes = root.getChildNodes();
			assertTrue("number of child nodes for this request should be 5",
					(nodes.getLength() == 5));

			int numArgs = 0;

			for (int i = 0; i < nodes.getLength(); i++) {
				Node node = nodes.item(i);
				if (node.getNodeName().equals("command")) {
					assertEquals("Command should be commandName", node
							.getTextContent(), "commandName");
				} else if (node.getNodeName().equals("noderange")) {
					assertEquals("noderange should be n5-6", node
							.getTextContent(), "n5-6");
				} else if (node.getNodeName().equals("arg")) {
					assertTrue("args should be arg1-3", node.getTextContent()
							.startsWith("arg"));
					numArgs++;
				}
			}

			assertTrue("Should have 3 args", (numArgs == 3));

		} catch (ParserConfigurationException e) {
			fail("should not die");
		}
	}

	public void testXmlToOutputStream() {

		Map<String, Object> map = new HashMap<String, Object>();

		map.put("command", "commandName");
		map.put("noderange", "n5-6");

		List<String> args = new ArrayList<String>();
		args.add("arg1");
		args.add("arg2");
		args.add("arg3");

		map.put("arg", args);

		try {
			Document doc = XcatUtilities.createXmlDocument(map);
			IOString ioString = new IOString();

			XcatUtilities.xmlToOutputStream(doc, ioString.getOutputStream());

			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			InputSource inputSource = new InputSource(ioString.getInputStream());

			parser.parse(inputSource, new SpecificRequestParser());

		} catch (Throwable e) {
			fail("should not fail: " + e.toString());
		}

	}
}

class SpecificRequestParser extends DefaultHandler {

	private String content;

	private boolean hitRequestTag = false;

	@Override
	public void startElement(String uri, String localName, String name,
			Attributes attributes) throws SAXException {
		if (name.equals(XcatConstants.REQUEST_ROOT_XML_TAG)) {
			hitRequestTag = true;
		} else if (hitRequestTag == false) {
			throw new SAXParseException(
					"Should not have any other tag before the request tag: "
							+ name, null);
		}
	}

	@Override
	public void endElement(String uri, String localName, String name)
			throws SAXException {
		
		if (name.equals("command")) {
			if (!content.equals("commandName")) {
				throw new SAXParseException(
						"command tag should have value 'commandName' instead is: "
								+ content, null);
			}
		} else if (name.equals("noderange")) {
			if (!content.equals("n5-6")) {
				throw new SAXParseException(
						"noderange tag should have value 'n5-6' instead is: "
								+ content, null);
			}
		} else if (name.equals("arg")) {
			if (!content.startsWith("arg")) {
				throw new SAXParseException(
						"arg tag should start with 'arg' instead is: "
								+ content, null);
			}
		} else if (name.equals("cwd")) {
			if (content == null) {
				throw new SAXParseException(
						"cwd tag should not be null", null);
			}
		} else if (!name.equals(XcatConstants.REQUEST_ROOT_XML_TAG)){
			throw new SAXParseException(
					"Unkown tag: " + name, null);
		}

		content = null;
	}

	@Override
	public void characters(char buf[], int offset, int len) throws SAXException {
		String temp2;
		temp2 = new String(buf, offset, len).trim();
		if (!temp2.equals("")) {
			content = temp2;
		}
	}
}
