package com.cri.xcat.api;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;

import com.cri.xcat.api.helpers.BasicRequest;

import junit.framework.TestCase;

public class BasicRequestTest extends TestCase {

	public void testBasicRequestCreation() {
		BasicRequest request = new BasicRequest("commandName");
		request.setNodeRange("n5-6");

		String[] args = new String[3];
		args[0] = "arg1";
		args[1] = "arg2";
		args[2] = "arg3";

		request.setArgs(args);

		IOString ioString = new IOString();
		try {
			request.buildXmlOutputStream(ioString.getOutputStream());
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			InputSource inputSource = new InputSource(ioString.getInputStream());

			parser.parse(inputSource, new SpecificRequestParser());

		} catch (Throwable e) {
			fail("Should not fail: " + e.toString());
		}
	}

	public void testBasicRequestOptions() {
		BasicRequest request = new BasicRequest("commandName");
		try {
			request.setCommandName(null);
			fail("Cannot set command name to null");
		} catch (IllegalArgumentException e) {
			// Should fail when setting command name to null
		}

		try {
			request = new BasicRequest("commandName");
			request.setCurrentWorkingDirectory("a working directory");

			IOString ioString = new IOString();

			request.buildXmlOutputStream(ioString.getOutputStream());
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			InputSource inputSource = new InputSource(ioString.getInputStream());

			parser.parse(inputSource, new SpecificRequestParser());

		} catch (Throwable e) {
			fail("Should not fail: " + e.toString());
		}

	}
}
