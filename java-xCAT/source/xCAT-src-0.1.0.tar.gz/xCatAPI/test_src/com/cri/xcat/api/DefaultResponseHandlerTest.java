package com.cri.xcat.api;

import java.util.List;
import java.util.Map;

import com.cri.xcat.api.helpers.DefaultResponseHandler;

import junit.framework.TestCase;

public class DefaultResponseHandlerTest extends TestCase {

	public void testNormalResponse1() {
		IOString ioString = new IOString("<" + XcatConstants.RESPONSE_ROOT_XML_TAG + ">"
				+ "<data>first data information</data>" + "<data>more data information</data></"
				+ XcatConstants.RESPONSE_ROOT_XML_TAG + ">");

		DefaultResponseHandler drh = new DefaultResponseHandler();
		drh.handleXmlResponse(ioString.getInputStream());

		Map<String, List<String>> xmlMap = drh.getResponseData();

		assertTrue("Default Handler parsed data information", xmlMap.containsKey("data"));
		assertTrue("Default Handler contains 2 data tag information messages", xmlMap.get("data")
				.size() == 2);
		assertTrue("data tags parsed 2 messages correctly", xmlMap.get("data").contains(
				"first data information"));
		assertTrue("data tags parsed 2 messages correctly", xmlMap.get("data").contains(
				"more data information"));

		assertTrue("Handler only contains 1 key: data", xmlMap.keySet().size() == 1);
	}

	public void testNormalResponse2() {
		IOString ioString = new IOString("<" + XcatConstants.RESPONSE_ROOT_XML_TAG + ">"
				+ "<data><desc>desc1</desc>" + "<contents>contents 1</contents>"
				+ "<desc>desc2</desc>" + "<contents>contents 2</contents> " + "</data></"
				+ XcatConstants.RESPONSE_ROOT_XML_TAG + ">");

		DefaultResponseHandler drh = new DefaultResponseHandler();
		drh.handleXmlResponse(ioString.getInputStream());

		Map<String, List<String>> xmlMap = drh.getResponseData();

		assertTrue("Default Handler contains 2 desc tag information messages", xmlMap.get("desc")
				.size() == 2);
		assertTrue("desc tags parsed 2 messages correctly", xmlMap.get("desc").contains("desc1"));
		assertTrue("desc tags parsed 2 messages correctly", xmlMap.get("desc").contains("desc2"));

		assertTrue("Default Handler contains 2 contents tag information messages", xmlMap.get(
				"contents").size() == 2);
		assertTrue("contents tags parsed 2 messages correctly", xmlMap.get("contents").contains(
				"contents 1"));
		assertTrue("contents tags parsed 2 messages correctly", xmlMap.get("contents").contains(
				"contents 2"));

		assertTrue("Handler only contains 2 keys: desc & contents", xmlMap.keySet().size() == 2);
	}

	public void testNormalResponse3() {
		IOString ioString = new IOString("<" + XcatConstants.RESPONSE_ROOT_XML_TAG + ">"
				+ "<node><name>node001</name>" + "<data><desc>node001 desc</desc>"
				+ "<contents>node001 contents</contents>" + "</data></node>"
				+ "<node><name>node002</name>" + "<data><desc>node002 desc</desc>"
				+ "<contents>node002 contents</contents>" + "</data></node>" + "</"
				+ XcatConstants.RESPONSE_ROOT_XML_TAG + ">");

		DefaultResponseHandler drh = new DefaultResponseHandler();
		drh.handleXmlResponse(ioString.getInputStream());

		Map<String, List<String>> xmlMap = drh.getResponseData();

		assertTrue("Default Handler contains 2 name tag information messages", xmlMap.get("name")
				.size() == 2);
		assertTrue("name tags parsed 2 messages correctly", xmlMap.get("name").contains("node001"));
		assertTrue("name tags parsed 2 messages correctly", xmlMap.get("name").contains("node002"));

		assertTrue("Default Handler contains 2 desc tag information messages", xmlMap.get("desc")
				.size() == 2);
		assertTrue("desc tags parsed 2 messages correctly", xmlMap.get("desc").contains(
				"node001 desc"));
		assertTrue("desc tags parsed 2 messages correctly", xmlMap.get("desc").contains(
				"node002 desc"));

		assertTrue("Default Handler contains 2 contents tag information messages", xmlMap.get(
				"contents").size() == 2);
		assertTrue("contents tags parsed 2 messages correctly", xmlMap.get("contents").contains(
				"node001 contents"));
		assertTrue("contents tags parsed 2 messages correctly", xmlMap.get("contents").contains(
				"node002 contents"));

		assertTrue("Handler only contains 3 keys: name, desc, and contents",
				xmlMap.keySet().size() == 3);
	}

	public void testExtraXMLInformation() {
		IOString ioString = new IOString("<" + XcatConstants.RESPONSE_ROOT_XML_TAG + ">"
				+ "<data>first data information</data>" + "<data>more data information</data></"
				+ XcatConstants.RESPONSE_ROOT_XML_TAG + ">" + "</" + XcatConstants.RESPONSE_ROOT_XML_TAG + ">"
				+ "<data>should not be included</data>" + "<badtag>information</badtag></"
				+ XcatConstants.RESPONSE_ROOT_XML_TAG + ">");

		DefaultResponseHandler drh = new DefaultResponseHandler();
		drh.handleXmlResponse(ioString.getInputStream());

		Map<String, List<String>> xmlMap = drh.getResponseData();

		assertTrue("Default Handler parsed data information", xmlMap.containsKey("data"));
		assertTrue("Default Handler contains 2 data tag information messages", xmlMap.get("data")
				.size() == 2);
		assertTrue("data tags parsed 2 messages correctly", xmlMap.get("data").contains(
				"first data information"));
		assertTrue("data tags parsed 2 messages correctly", xmlMap.get("data").contains(
				"more data information"));

		assertTrue("Handler only contains 1 key: data", xmlMap.keySet().size() == 1);
	}

	public void testOtherXmlFormat() {
		IOString ioString = new IOString("<" + XcatConstants.RESPONSE_ROOT_XML_TAG + ">"
				+ "<error>Unable to identify plugin for this command, "
				+ "check relevant tables: noderes.netboot</error>" + "<errorcode>1</errorcode></"
				+ XcatConstants.RESPONSE_ROOT_XML_TAG + ">");

		DefaultResponseHandler drh = new DefaultResponseHandler();
		drh.handleXmlResponse(ioString.getInputStream());

		Map<String, List<String>> xmlMap = drh.getResponseData();

		assertTrue("Handler only contains 2 keys: error & errorcode", xmlMap.keySet().size() == 2);

		assertTrue("Default Handler parsed error information", xmlMap.containsKey("error"));
		assertTrue("data tags parsed error message correctly", xmlMap.get("error").get(0).equals(
				"Unable to identify plugin for this command, "
						+ "check relevant tables: noderes.netboot"));

		assertTrue("errorcode tags parsed correctly", xmlMap.get("errorcode").get(0).equals("1"));

	}
}
